<body>
      <nav class="navbar navbar-expand-md bg-dark navbar-dark sticky-top">
  <a class="navbar-brand acme" href="index.php">FREE2SMS</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
    
    <li class="nav-item">
    <a class="nav-link" href="login.php">LOG IN</a>
    </li>
      
      <li class="nav-item">
        <a class="nav-link" href="register.php">SIGN UP</a>
      </li>
      
   <li class="nav-item">
   <a class="nav-link" href="reset-pass.php">RESET PASSWORD</a>
   </li>
   
      
    </ul>
  </div>
</nav>
<div class="jumbotron" align="center">
 <img src="https://free2sms.ml/logo.png" alt="Apgy Games" width="150px" class="logoo"/>
 <br/>
 <h2 class="brush">BULK SMS SERVICE PROVIDER</h2>
 <p class="acme">FREE BULK SMS SERVICE FOR EVERYONE</p>
 </div>
 