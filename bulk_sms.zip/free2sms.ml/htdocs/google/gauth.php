<?php
require_once('settings.php');
require_once('google-login-api.php');

// Google passes a parameter 'code' in the Redirect Url
if(isset($_GET['code'])) {
	try {
		$gapi = new GoogleLoginApi();
		
		// Get the access token 
		$data = $gapi->GetAccessToken(CLIENT_ID, CLIENT_REDIRECT_URL, CLIENT_SECRET, $_GET['code']);
		
		// Get user information
		$user_info = $gapi->GetUserProfileInfo($data['access_token']);
	}
	catch(Exception $e) {
		echo $e->getMessage();
		exit();
	}
}
?>
<!DOCTYPE html>
<html>
<head>
<meta name="theme-color" content="#131A22">
    <!-- Windows Phone -->
    <meta name="msapplication-navbutton-color" content="#131A22">
    <!-- iOS Safari -->
    <meta name="apple-mobile-web-app-status-bar-style" content="#131A22">
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="upload/<?php echo $url ?>" type="image/x-icon"/>
    <link rel="shortcut icon" href="upload/<?php echo $url ?>" type="image/x-icon"/>
    <title>
    <?php echo $name ?>
   </title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
  box-sizing: border-box;
}

body {
  margin: 0;
  font-family: Arial;
}

/* The grid: Four equal columns that floats next to each other */
.column {
  float: left;
  width: 25%;
  padding: 10px;
}

/* Style the images inside the grid */
.column img {
  opacity: 0.8; 
  cursor: pointer; 
}

.column img:hover {
  opacity: 1;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* The expanding image container */
.container {
  position: relative;
  display: none;
}

/* Expanding image text */
#imgtext {
  position: absolute;
  bottom: 15px;
  left: 15px;
  color: white;
  font-size: 20px;
}

/* Closable button inside the expanded image */
.closebtn {
  position: absolute;
  top: 10px;
  right: 15px;
  color: red;
  font-size: 35px;
  cursor: pointer;
}
</style>
<style>
	* {
	box-sizing: border-box;
	}
	
	body {
	font-family: Arial, Helvetica, sans-serif;
	}
	
	/* Float four columns side by side */
	#column {
	float: left;
	width: 25%;
	padding: 0 10px;
	}
	
	/* Remove extra left and right margins, due to padding */
	#row {margin: 0 ;}
	
	/* Clear floats after the columns */
	#row:after {
	content: "";
	display: table;
	clear: both;
	}
	
	/* Responsive columns */
	@media screen and (max-width: 600px) {
	#column {
	width: 100%;
	display: block;
	margin-bottom: 20px;
	}
	}
	
	/* Style the counter cards */
	#card {
	box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
	padding: 16px;
	text-align: left;
	background-color: #f1f1f1;
	}
	p {
	text-align:left;
	}
	.aa {
	text-align:center;
	}
	.btn {
	background-color: #FF9900;
	color: white;
	padding: 12px 20px;
	border: none;
	border-radius: 4px;
	cursor: pointer;
	align:right;
	}
	
	.btn hover {
	background-color: #45a049;
	}
	
	</style>
	<style>
	body {
	background:#f2f2f2;
	font-family: "Lato", sans-serif;
	}
	
	.sidenav {
	height: 100%;
	width: 0;
	position: fixed;
	z-index: 1;
	top: 0;
	left: 0;
	background-color: red; /* For browsers that do not support gradients */
	background:#232F3E; /* Standard syntax (must be last) */
	
	overflow-x: hidden;
	transition: 0.5s;
	padding-top: 60px;
	}
	
	.sidenav a {
	padding: 8px 8px 8px 32px;
	text-decoration: none;
	font-size: 20px;
	color: #fff;
	display: block;
	transition: 0.3s;
	}
	
	.sidenav a:hover {
	color: #f1f1f1;
	}
	
	.sidenav .closebtn {
	position: absolute;
	top: 0;
	right: 25px;
	font-size: 36px;
	margin-left: 50px;
	}
	
	@media screen and (max-height: 450px) {
	.sidenav {padding-top: 15px;}
	.sidenav a {font-size: 18px;}
	}
	.spn {
	color: #fff;
	}
	</style>
	<style>
	* {
	box-sizing: border-box;
	}
	
	body {
	font-family: Arial, Helvetica, sans-serif;
	}
	
	/* Style the header */
	header {
	height: 200px;
	background:#37475A; /* Standard syntax (must be last) */
	
	padding: 30px;
	text-align: left;
	font-size: 35px;
	color: white;
	}
	
	/* Create two columns/boxes that floats next to each other */
	nav {
	float: left;
	width: 30%;
	height: 300px; /* only for demonstration, should be removed */
	background: #ccc;
	padding: 20px;
	}
	
	/* Style the list inside the menu */
	nav ul {
	list-style-type: none;
	padding: 0;
	}
	
	article {
	float: left;
	padding: 20px;
	width: 70%;
	background-color: #f1f1f1;
	height: 300px; /* only for demonstration, should be removed */
	}
	
	/* Clear floats after the columns */
	section:after {
	content: "";
	display: table;
	clear: both;
	}
	
	/* Style the footer */
	footer {
	
	background:#37475A; /* Standard syntax (must be last) */
	
	padding: 10px;
	text-align: center;
	color: white;
	}
	.pp {
	text-align: center;
	}
	
	.avatar{
	width: 100px;
	height: 100px;
	border-radius: 50%;
	position: absolute;
	
	left: calc(50% - 50px);
	}
	</style>
</head>

<body>
<script type="text/javascript">
window.onload = () => {
    let el = document.querySelector('[alt="www.000webhost.com"]').parentNode.parentNode;
    el.parentNode.removeChild(el);
}
</script>
<header>
<div id="mySidenav" class="sidenav">
 
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="profile.php">ADD NUMBERS</a>
  
</div>
<span class="spn" style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776;</span>
<center>
<h5>USER INFO</h5>
</center>
</header>



<script>
function myFunction(imgs) {
  var expandImg = document.getElementById("expandedImg");
  var imgText = document.getElementById("imgtext");
  expandImg.src = imgs.src;
  imgText.innerHTML = imgs.alt;
  expandImg.parentElement.style.display = "block";
}
</script>
<div id="row">
<div id="column">
<div id="card">
<center>

   <img class="avatar" src="<?= $user_info['picture'] ?>" />
                            

</center>
                              
<br>
<br>
<br>
<br>
<br>
<h4>Name:- <?= $user_info['name'] ?></h4>
<h4>Email:- <?= $user_info['email'] ?></h4>
<h4>Number:- <?= $user_info['number'] ?></h4>

<h4>Gender:- <?= $user_info['gender'] ?></h4>

<h4>ID:- <?= $user_info['id'] ?></h4>
<h4>Email Verified:- <?= $user_info['verified_email'] == true ? 'Yes' : 'No' ?>
		</h4>

</div>
</div>
</div>
</body>
<footer>
<centet>
<p class="pp">DEVELOPED BY IBNE ALAM KHAN</p>
</centet>
</footer>
</html>