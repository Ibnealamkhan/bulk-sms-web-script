<?php

/* Google App Client Id */
define('CLIENT_ID', '363392307477-iq8ir8ud0rmkk2i7e45taellvbf8qs3v.apps.googleusercontent.com');

/* Google App Client Secret */
define('CLIENT_SECRET', 'ywnE1T8qOQUHO9tg9VKoyq-V');

/* Google App Redirect Url */
define('CLIENT_REDIRECT_URL', 'https://free2sms.ml/google/gauth.php');

?>