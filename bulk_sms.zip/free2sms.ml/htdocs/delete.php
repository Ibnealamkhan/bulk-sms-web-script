<?php
$con=mysqli_connect("sql212.epizy.com","epiz_23987377","P0kUisJk","epiz_23987377_sms");

$id = $_GET["id"];



$statement=mysqli_query($con, "DELETE FROM userregistration WHERE email='{$id}' ");

echo header("location: login.php?mid=Your Number $id Has Been Deleted Successfully");


mysqli_close($con);

?>