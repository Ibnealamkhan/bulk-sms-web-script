<?php

session_start();

/*
##### DB Configuration #####
$servername = "sql100.epizy.com";
$username = "epiz_24555717";
$password = "vCl8hr7bg0zGwDq";
$db = "epiz_24555717_sms";
*/
##### Google App Configuration #####
$googleappid = "363392307477-5ijds4vqids7hhk22skkllfusj36rji9.apps.googleusercontent.com"; 
$googleappsecret = "V8cFt6cYUzYIK1ujXztds2BS"; 
// $redirectURL = "http://localhost:81/LoginwithGoogle/authenticate.php"; 
$redirectURL = "https://free2sms.ml/authenticate.php"; 
/*
##### Create connection #####
$conn = new mysqli($servername, $username, $password, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
*/
##### Required Library #####
include_once 'src/Google/Google_Client.php';
include_once 'src/Google/contrib/Google_Oauth2Service.php';

$googleClient = new Google_Client();
$googleClient->setApplicationName('FREE2SMS');
$googleClient->setClientId($googleappid);
$googleClient->setClientSecret($googleappsecret);
$googleClient->setRedirectUri($redirectURL);

$google_oauthV2 = new Google_Oauth2Service($googleClient);

?>