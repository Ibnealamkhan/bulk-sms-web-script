<?php
session_start();
include_once("connection.php");
include_once("includes/header.php");
include_once("includes/navbar.php");
if($_SESSION['login'])
{
 ?>
 <?php
 include_once("connection.php");
 $email=$_SESSION['login'];
 $query = "SELECT COUNT(*) AS 'source' FROM `smshistory` WHERE email = '$email' and source = 'API'";
 $run_query = mysqli_query($conn, $query) or die(mysqli_error($conn));
 if (mysqli_num_rows($run_query) > 0) {
 while ($row = mysqli_fetch_array($run_query)) {
 $Acount = $row['source'];
 
 }
 }
  ?>
 <?php
 include_once("connection.php");
 $email=$_SESSION['login'];
 $query = "SELECT COUNT(*) AS 'source' FROM `smshistory` WHERE email = '$email' and source = ''";
 $run_query = mysqli_query($conn, $query) or die(mysqli_error($conn));
 if (mysqli_num_rows($run_query) > 0) {
 while ($row = mysqli_fetch_array($run_query)) {
 $Dcount = $row['source'];
 
 }
 }
 
?>
 <div class="container" align="center">
 <h2>SMS ANALYTICS</h2>
 <div class="card shadow">
 <div id="piechart_3d" style="width: 100%; height: 100%;"></div>
 
 </div>
 </div>

<div class="container" align="center">
<h2>SMS HISTORY</h2>
     <div class="card shadow">
<div class="row">
<div class="col-lg-12">
        <div class="table-responsive">

            <table class="table table-bordered table-striped table-hover">

    <thead>
      <tr>
      <?php
      include_once("connection.php");
      $email=$_SESSION['login'];
      $query = "SELECT COUNT(*) AS `phone` FROM `smshistory` WHERE email = '$email'";
      $run_query = mysqli_query($conn, $query) or die(mysqli_error($conn));
      if (mysqli_num_rows($run_query) > 0) {
      while ($row = mysqli_fetch_array($run_query)) {
      $count = $row['phone'];
      }
      }
      
      echo "
        <p>Total sms count  $count </p>";
        ?>
        <p>LAST 10 SMS</p>
        <th>Number</th>
        <th>Sender ID</th>
        <th>Message</th>
        <th>Date</th>
  
      </tr>
    </thead>
    <tbody>
             <?php 
            
             if ($limit = $_GET['limit']){
           
             }
             else {
             $limit="10";
             }
             ?>
<?php

 $email=$_SESSION['login'];
  $query = "SELECT * FROM smshistory WHERE email= '$email' ORDER BY date DESC LIMIT $limit ";
  $run_query = mysqli_query($conn, $query) or die(mysqli_error($conn));
  if (mysqli_num_rows($run_query) > 0) {
  while ($row = mysqli_fetch_array($run_query)) {
  $phone = $row['phone'];
 $senderid = $row['senderid'];
 $email = $row['email'];
 $message = $row['message'];
 $date = $row['date'];
 $source = $row['source'];
 
 echo "<tr>";
 echo "<td>$phone <p class='font'>$source</p></td>";
 echo "<td>$senderid</td>";
 echo "<td>$message</td>";
 echo "<td>$date</td>"; 
 echo "</tr>";
 echo "</tbody>";
 }
  
  }
 
  
?>
<a class='button' href='?limit=200'>View All Records</a>
 
</tbody>
  </table>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<style>
.font {
font-size:10px;
color:green;
}
</style>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Task', 'Hours per Day'],
          ['DEFAULT',     <?php echo $Dcount ?> ],
          ['API',      <?php echo $Acount ?> ],
         
        ]);

        var options = {
          title: 'SMS ANALYTICS',
          is3D: true,
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart_3d'));
        chart.draw(data, options);
      }
    </script>
<?php include_once("includes/footer.php"); ?>
<?php
} else {
header('location:logout.php');	
}
?>