
<?php
session_start();
include_once("connection.php");
include_once("includes/header.php");
include_once("includes/navbar.php");
if($_SESSION['login'])
{
 ?>
 <?php
 $email = $_SESSION['login'];
 $query = "SELECT * FROM userregistration WHERE email = '$email'" ; 
 $result= mysqli_query($conn , $query) or die (mysqli_error($conn));
 if (mysqli_num_rows($result) > 0 ) {
 $row = mysqli_fetch_array($result);
 $api = $row['api'];
 $pass= $row['password'];
 
 
  
        }
        if (isset($_POST['uploadphoto'])) {
        $email = $_SESSION['login'];
        $api = md5($_SESSION['login']);
         $queryupdate = "UPDATE userregistration SET api = '$api' WHERE email= '$email' " ;
        $result = mysqli_query($conn , $queryupdate) or die(mysqli_error($conn));
        if (mysqli_affected_rows($conn) > 0) {
         echo "<script>alert('API $api Successfully Generated');
         window.location.href= 'UserApi.php';</script>";
         
        }
        else {
        echo "<script>alert('API Already Generated');</script>";
        }
        }
          
        
        
        ?>
       
    
    
<br/>
<div class="container" align="center">

     <div class="card shadow">

  
  <form action="" method="post">
    <input class="btn btn-outline-success btn-block" type="submit" name="uploadphoto" value="GENERATE API">
   
    </form>
    
<br>
<input type="text" value="<?php echo $api ?>" id="myInput" readonly>

<!-- The button used to copy the text -->
<button class="button" onclick="myFunction()">Copy API</button>
<script type="text/javascript">
function myFunction() {
  /* Get the text field */
  var copyText = document.getElementById("myInput");

  /* Select the text field */
  copyText.select();

  /* Copy the text inside the text field */
  document.execCommand("copy");

  /* Alert the copied text */
  alert("Copied API: " + copyText.value);
}
</script>
   
   <br>
   <p class="p">GET METHOD LINK</p>
   
   <input type="text" value="http://f2sms.epizy.com?api=<?php echo $api ?>&pass=<?php echo $pass ?>" id="url" readonly>
   
   <!-- The button used to copy the text -->
   <button class="button" onclick="url()">COPY GET METHOD LINK</button>
   <script type="text/javascript">
   function url() {
   /* Get the text field */
   var copyText = document.getElementById("url");
   
   /* Select the text field */
   copyText.select();
   
   /* Copy the text inside the text field */
   document.execCommand("copy");
   
   /* Alert the copied text */
   alert("Copied API: " + copyText.value);
   }
   </script>
 </div>
 </div>
 <style>
 .button {
 background-color: #4CAF50;
 color: white;
 padding: 14px 20px;
 margin: 8px 0;
 border: none;
 cursor: pointer;
 width: 100%;
 }
 input[type=text], input[type=tel], .message {
 width: 100%;
 padding: 12px 20px;
 margin: 8px 0;
 display: inline-block;
 border: 1px solid #ccc;
 box-sizing: border-box;
 }
 .p {
 text-align:left;
 font-size:20px;
 color:red;
 }
 </style>
<?php
} else {
header('location:logout.php');	
}
?>
<?php include_once("includes/footer.php"); ?>