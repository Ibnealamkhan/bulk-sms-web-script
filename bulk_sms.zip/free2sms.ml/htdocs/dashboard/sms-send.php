
<?php
session_start();
include_once("dbConnection.php");
include_once("config.php");
include_once("connection.php");
include_once("includes/header.php");
include_once("includes/navbar.php");
if($_SESSION['login'])
{
 ?>
 <style>
 .alert{
 text-align: center;
 padding:10px;
 background:#79c879;
 color:#fff;
 margin-bottom:10px;
 display:block;
 }
 </style>
 <!-- AD SPACE -->
 <!-- apgygames top -->
 
 <br/>


<?php 
 if(isset($_POST['submit']))
 {

 date_default_timezone_set("Asia/Kolkata");
 $email= $_SESSION['login'];
 $mobileNo=$_POST['mobile'];
 $message = $_POST['message'];
 
 $senderId =$_POST['sender'];
 
 $date= date("Y/m/d h:i:sa");
 $query = "SELECT * FROM affiliate WHERE email= '$email'";
 $run_query = mysqli_query($conn, $query) or die(mysqli_error($conn));
 if (mysqli_num_rows($run_query) > 0) {
 while ($row = mysqli_fetch_array($run_query)) {
 $amount = $row['amount'];
 
 if($amount>0)
 {
   $sql = "UPDATE affiliate SET amount = amount-1 WHERE email= '$email'";
   $conn->query($sql);
     $query=mysqli_query($con,"insert into smshistory (email,phone,senderid,message,date,source) values('$email','$mobileNo','$senderId','$message','$date','')");
     
     mysqli_query($con,$query);}
 else {
 
 echo "<script>alert('You Have No Balance To SEND Sms');</script>";
 echo "<script>window.location = 'sms.php';</script>";;
 
 }
 }
 }
 else {
  echo "<script>alert('You Dont Have A FREE2SMS Affiliate Account click OK For Create Account');</script>";
  echo "<script>window.location = 'affiliate.php';</script>";;
 
 }
 }
 ?>
 
<div class="container" align="center">
     <!-- AD SPACE -->
   <!-- apgygames top -->

         <div class="card shadow">
         
         <form action="send.php" method="post" >
         
       
         <input  type="hidden" value="<?php echo $mobileNo ?>"required name="mobile" readonly>
          <input class="form-control" type="hidden" value="<?php echo $senderId ?>"required name="sender" minlength="6" maxlength="6" <?php echo $_SESSION['action'];?>>
         <span class="highlight"></span>
         <span class="bar"></span>
         <label>CONFORM YOUR MESSAGE BEFORE SENDING</label>
         
         <textarea class="message" placeholder="Enter Your Massage" class="text" rows="5" name="message" readonly><?php echo $message ?></textarea>
         <span class="highlight"></span>
         <span class="bar"></span>
         </textarea>
         
         <br>
         <center> <button class="button"  type="submit" name="submit" class="btn">CONFORM<span class="glyphicon glyphicon-send"></span></button></center>

         <br>
         </form>
         </div>
         </div>
         
         <style>
         
         body {font-family: Arial, Helvetica, sans-serif;}
         form {border: 3px solid #fff;}
         
         input[type=text], input[type=tel], .message {
         width: 100%;
         padding: 12px 20px;
         margin: 8px 0;
         display: inline-block;
         border: 1px solid #ccc;
         box-sizing: border-box;
         }
         
         .button {
         background-color: #4CAF50;
         color: white;
         padding: 14px 20px;
         margin: 8px 0;
         border: none;
         cursor: pointer;
         width: 100%;
         }
         .error {
         background-color: #4CAF50;
         color: white;
         padding: 14px 20px;
         margin: 8px 0;
         border: none;
         cursor: pointer;
         width: 300px;
         
         }
         
         .button:hover {
         opacity: 0.8;
         }
         
         .cancelbtn {
         width: auto;
         padding: 10px 18px;
         background-color: #f44336;
         }
         
         .imgcontainer {
         text-align: center;
         margin: 24px 0 12px 0;
         }
         
         img.avatar {
         width: 40%;
         border-radius: 50%;
         }
         
         .container {
         padding: 16px;
         }
         
         span.psw {
         float: right;
         padding-top: 16px;
         }
         
         /* Change styles for span and cancel button on extra small screens */
         @media screen and (max-width: 5px) {
         span.psw {
         display: block;
         float: none;
         }
         .cancelbtn {
         width: 50%;
         }
         }
         </style>
<?php
} else {
header('location:logout.php');	
}
?>
<?php include_once("includes/footer.php"); ?>