</body>

         <style>
         .footer {
         position: responsive;
         left: 0;
         bottom: 0;
         width: 100%;
         background-color:#343a40;
         color: white;
         text-align: center;
         height:110px;
         }
         </style>
         <br>
         <div class="footer">
         <br>
         <ul class="list-unstyled list-inline social text-center">
         <li class="list-inline-item"><a href="https://facebook.com/ibnealamkhan1" target="_blank" rel="nofollow"><i class="fab fa-facebook"></i></a></li>
         <li class="list-inline-item"><a href="https://twitter.com/ibnealamkhan2" target="_blank" rel="nofollow"><i class="fab fa-twitter"></i></a></li>
         <li class="list-inline-item"><a href="https://www.instagram.com/ibnealam.khan" target="_blank" rel="nofollow"><i class="fab fa-instagram"></i></a></li>
         <li class="list-inline-item"><a href="mailto:ibnealamkhan811@gmail.com" target="_blank" rel="nofollow"><i class="fa fa-envelope"></i></a></li>
         </ul>
         <p>Developed & Designed By Ibne Alam Khan</p>
         </div>
         </div>
         </html>