<?php
include_once("dbConnection.php");
include_once("includes/header.php");
include_once("includes/navbar.php");
 ?>
<body>
      <nav class="navbar navbar-expand-md bg-dark navbar-dark sticky-top">
  <a class="navbar-brand acme" href="index.php">Hello, <?php echo $_SESSION['name'];?></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
    
    <li class="nav-item">
    <a class="nav-link" href="profile.php">PROFILE</a>
    </li>
      
      <li class="nav-item">
        <a class="nav-link" href="sms.php">SEND SMS</a>
      </li>
      
      <li class="nav-item">
      <a class="nav-link" href="sms-history.php">SMS HISTORY</a>
      </li>
      
      <li class="nav-item">
      <a class="nav-link" href="UserApi.php">USER API</a>
      </li>
      
      <li class="nav-item">
      <a class="nav-link" href="affiliate.php">EARN MONEY</a>
      </li>
      <li class="nav-item">
      <a class="nav-link" href="request-senderid.php">REQUEST CUSTOM SENDER ID</a>
      </li>
      
      <li class="nav-item">
      <a class="nav-link" href="verified-senderid.php">VERIFIED SENDER ID</a>
      </li>
      
     <li class="nav-item">
     <a class="nav-link" href="logout.php">LOG OUT AS, <?php echo $_SESSION ['name'];?></a>
     </li>
     
     
     
      
    </ul>
  </div>
</nav>


<div class="jumbotron" align="center">
 <img src="https://free2sms.ml/logo.png" alt="Apgy Games" width="150px" class="logoo"/>
 <br/>
 <h2 class="brush">BULK SMS SERVICE PROVIDER</h2>
 <p class="acme">FREE BULK SMS SERVICE FOR EVERYONE</p>
 </div>