<style>
.avatar {
width: 100px;
height: 100px;
border-radius: 50%;
position: absolute;

left: calc(50% - 50px);
}
</style>
<style>
body{
 line-height:2;
 font-family:calibri;
}
.formarea{
 width:auto;
 margin:0 auto;
 background-color:#fff; 
 text-align:left;
 padding:4%;
 border-radius:5px;
}
 
#bararea{
 width:100%;
 height:40px;
 border:2px solid #fff;
}
 
#bar{
 width:0%;
 margin:4px 0;
 height:32px;
 background-color:#4CAF50;
}
 
#status{
 color:#000;
}
form {border: 3px solid #f1f1f1;}

input[type=text], input[type=file], input[type=tel], input[type=email] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}
.button {
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

.button:hover {
  opacity: 0.8;
}
</style>
</head>


	
<?php
session_start();
include_once("connection.php");
include_once("includes/header.php");
include_once("includes/navbar.php");
if($_SESSION['login'])
{
 ?>
 <?php
 $email = $_SESSION['login'];
 $query = "SELECT * FROM userregistration WHERE email = '$email'" ; 
 $result= mysqli_query($conn , $query) or die (mysqli_error($conn));
 if (mysqli_num_rows($result) > 0 ) {
 $row = mysqli_fetch_array($result);
 $img = $row['img'];
 $api = $row['api'];
 $name = $row['name'];
 $oauthpro = $row['oauthpro'];
 $address = $row['address'];
 $number = $row['number'];
 
 
 



    }
    ?>
    <?php
    if ($oauthpro=="google"){
    echo '
    <div class="container" align="center">
    
    <div class="card shadow">
    
    <img class="avatar" src="'.$img.'">
    <br><br><br><br><br>
    <p>Name:- '.$name.'</p>
    <p>Email:- '.$email.'</p>
    </div>
    </div>
    ';
    }
    else {
    echo '
    <div class="formarea">
    <div id="bararea">
    <div id="bar"></div>
    </div>
    
    <div id="percent"></div>
    <div id="status"></div>
    </div>
    <div class="container" align="center">
    
    <div class="card shadow">
    
    <img class="avatar" src="'.$img.'">
    <br><br><br><br><br>
    <form action="update-pic.php" method="post" enctype="multipart/form-data">
    <input type="file" name="image" required>
    <input type="hidden" name="email" value="'.$email.'">
    <button class="button">Upload</button>
    </form>
    
    
    <p>Name:- '.$name.' </p>
    <p>Email:- '.$email.'</p>
    <p>Number:- '.$number.'</p>
    <p>Address:- '.$address.'</p>
    
    
    
    
    <br>
    </div>
    </div>	
    ';
    }
    ?>
<br/>

 <script>
 $(function() {
 $(document).ready(function(){
 var bar = $('#bar')
 var percent = $('#percent');
 var status = $('#status');
 
 $('form').ajaxForm({
 beforeSend: function() {
 status.empty();
 var percentVal = '0%';
 bar.width(percentVal);
 percent.html(percentVal);
 },
 uploadProgress: function(event, position, total, percentComplete) {
 var percentVal = percentComplete + '%';
 percent.html(percentVal);
 bar.width(percentVal);
 },
 complete: function(xhr) {
 status.html(xhr.responseText);
 }
 });
 });
 });
 </script>
 <script src="https://code.jquery.com/jquery-2.2.0.min.js"></script>
 <script src="http://oss.maxcdn.com/jquery.form/3.50/jquery.form.min.js"></script>
 
<?php
} else {
header('location:logout.php');	
}
?>
<?php include_once("includes/footer.php"); ?>