<?php
session_start();
include_once("connection.php");
include_once("config.php");
include_once("dbConnection.php");
include_once("includes/header.php");
include_once("includes/navbar.php");
if($_SESSION['login'])
{
 ?>

 <div class="container" align="left">
 <div class='card shadow'>
 <div class="row">
 <div class="col-lg-12">
 <div class="table-responsive">
 
 <table class="table table-bordered table-striped table-hover">
 <center>
 <h3>PENDING SENDER ID</h3>
 </center>
 <thead>
 <tr>
 
 <th>Sender ID</th>
 <th>Status</th>
 <th>Date</th>
 
 </tr>
 </thead>
 <tbody>
 
 <?php

 $email=$_SESSION['login'];
 $query = "SELECT * FROM senderidrequest WHERE email= '$email' and status='PENDING'";
 $run_query = mysqli_query($conn, $query) or die(mysqli_error($conn));
 if (mysqli_num_rows($run_query) > 0) {
 while ($row = mysqli_fetch_array($run_query)) {
 
 $senderid = $row['senderid'];
 $email = $row['email'];
 $message = $row['message'];
 $date = $row['date'];
 $status = $row['status'];
 
 echo "<tr>";
 echo "<td>$senderid</td>";
 echo "<td>$status</td>";
 echo "<td>$date</td>"; 
 echo "</tr>";
 echo "</tbody>";
 }
 
 }
 ?>
 
 
 </tbody>
 </table>
 </div></div></div></div></div></div>
 
 <br>
 
 <div class="container" align="left">
 <div class='card shadow'>
 <div class="row">
 <div class="col-lg-12">
 <div class="table-responsive">
 
 <table class="table table-bordered table-striped table-hover">
 <center>
 <h3>REJECTED SENDER ID</h3>
 </center>
 <thead>
 <tr>
 
 <th>Sender ID</th>
 <th>Status</th>
 <th>Date</th>
 
 </tr>
 </thead>
 <tbody>
 
 <?php
 
 $email=$_SESSION['login'];
 $query = "SELECT * FROM senderidrequest WHERE email= '$email' and status='REJECTED'";
 $run_query = mysqli_query($conn, $query) or die(mysqli_error($conn));
 if (mysqli_num_rows($run_query) > 0) {
 while ($row = mysqli_fetch_array($run_query)) {
 
 $senderid = $row['senderid'];
 $email = $row['email'];
 $message = $row['message'];
 $date = $row['date'];
 $status = $row['status'];
 
 echo "<tr>";
 echo "<td>$senderid</td>";
 echo "<td>$status</td>";
 echo "<td>$date</td>"; 
 echo "</tr>";
 echo "</tbody>";
 }
 
 }
 ?>
 
 
 </tbody>
 </table>
 </div></div></div></div></div></div>
 <style>
 
 body {font-family: Arial, Helvetica, sans-serif;}
 form {border: 3px solid #fff;}
 
 input[type=text], input[type=tel], .message {
 width: 100%;
 padding: 12px 20px;
 margin: 8px 0;
 display: inline-block;
 border: 1px solid #ccc;
 box-sizing: border-box;
 }
 .alert{
 text-align: center;
 padding:10px;
 background:#79c879;
 color:#fff;
 margin-bottom:10px;
 display:block;
 }
 .button {
 background-color: #4CAF50;
 color: white;
 padding: 14px 20px;
 margin: 8px 0;
 border: none;
 cursor: pointer;
 width: 100%;
 }
 .error {
 background-color: #4CAF50;
 color: white;
 padding: 14px 20px;
 margin: 8px 0;
 border: none;
 cursor: pointer;
 width: 300px;
 
 }
 
 .button:hover {
 opacity: 0.8;
 }
 
 .cancelbtn {
 width: auto;
 padding: 10px 18px;
 background-color: #f44336;
 }
 
 .imgcontainer {
 text-align: center;
 margin: 24px 0 12px 0;
 }
 
 img.avatar {
 width: 40%;
 border-radius: 50%;
 }
 
 .container {
 padding: 16px;
 }
 
 span.psw {
 float: right;
 padding-top: 16px;
 }
 
 /* Change styles for span and cancel button on extra small screens */
 @media screen and (max-width: 5px) {
 span.psw {
 display: block;
 float: none;
 }
 .cancelbtn {
 width: 50%;
 }
 }
 </style>
 <style>
 body {font-family: Arial, Helvetica, sans-serif;}
 form {border: 3px solid #fff;}
 
 input[type=text], input[type=password], input[type=tel] {
 width: 100%;
 padding: 12px 20px;
 margin: 8px 0;
 display: inline-block;
 border: 1px solid #ccc;
 box-sizing: border-box;
 }
 select {
 width: 100%;
 padding: 12px 20px;
 margin: 8px 0;
 display: inline-block;
 border: 1px solid #ccc;
 box-sizing: border-box;
 }
 .button {
 background-color: #4CAF50;
 color: white;
 padding: 14px 20px;
 margin: 8px 0;
 border: none;
 cursor: pointer;
 width: 100%;
 }
 
 .button:hover {
 opacity: 0.8;
 }
 
 .cancelbtn {
 width: auto;
 padding: 10px 18px;
 background-color: #f44336;
 }
 
 .imgcontainer {
 text-align: center;
 margin: 24px 0 12px 0;
 }
 
 img.avatar {
 width: 40%;
 border-radius: 50%;
 }
 
 .container {
 padding: 16px;
 }
 
 span.psw {
 float: right;
 padding-top: 16px;
 }
 
 /* Change styles for span and cancel button on extra small screens */
 @media screen and (max-width: 300px) {
 span.psw {
 display: block;
 float: none;
 }
 .cancelbtn {
 width: 100%;
 }
 }
 .alert{
 text-align: center;
 padding:10px;
 background:#79c879;
 color:#fff;
 margin-bottom:10px;
 display:block;
 }
 </style>
 <style>
 .font {
 font-size:10px;
 color:green;
 }
 </style>
 <?php
 } else {
 header('location:logout.php');	
 }
 ?>
 <?php include_once("includes/footer.php"); ?>