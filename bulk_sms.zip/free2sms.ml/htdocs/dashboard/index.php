<?php
session_start();
include_once("dbConnection.php");
include_once("includes/header.php");
include_once("includes/navbar.php");
if(isset($_SESSION['login']))
{
 ?>

  <div class="container" align="center">
  <div class="card shadow">
  <a class="btn btn-outline-success btn-block" href="sms.php" >SEND SMS</a>
  <a class="btn btn-outline-success btn-block" href="sms-history.php" >VIEW SMS HISTORY</a>
  <br>
  </div>
  
  <br/>
  
  <div class="card shadow">
  <img class="card-img-top" src="https://www.webxion.com/img/bulk-sms-service.png" alt="Pre Register" style="width:100%">
  <div class="card-body">
  <h4 class="card-title acme">UNLIMITED FREE BULK SMS</h4>
  <a href="" class="stretched-link"></a>
  </div>
  </div>
  <br>
  
  <!-- AD SPACE -->
  <!-- apgygames bottom -->
  <div class="card shadow">
  <img class="card-img-top" src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTRgaMWa3OcCT-fyibz19Ozbz5uIt_z_uwxSC5NH8-tXUUcrFul" alt="Pre Register" style="width:100%">
  <div class="card-body">
  <h4 class="card-title acme">HOW TO SEND SMS</h4>
  <a href="" class="stretched-link"></a>
  </div>
  
  </div>
  <br>
  <div class="card shadow">
  <img class="card-img-top" src="https://www.ebulksms.in/images/300x250.gif" alt="Pre Register" style="width:100%">
  <div class="card-body">
  <h4 class="card-title acme">START YOUR ONLINE BUSINESS</h4>
  <a href="" class="stretched-link"></a>
  </div>
 
  </div>
  <br>
  <div class="card shadow">
  <div class="card-body">
  <h4 class="card-title acme">USER REALTIME LOCATION</h4>
  
  <script type="text/javascript" src="//rf.revolvermaps.com/0/0/8.js?i=5akmeldw08t&amp;m=0&amp;c=00ff00&amp;cr1=ffffff&amp;f=arial&amp;l=33" async="async"></script>
  
  </div>
  </div>
  </div>
<?php
} else {
header('location:logout.php');	
}

?>
<?php include_once("includes/footer.php"); ?>