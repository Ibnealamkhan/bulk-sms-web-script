<?php
session_start();
include_once("connection.php");
include_once("config.php");
include_once("dbConnection.php");
include_once("includes/header.php");
include_once("includes/navbar.php");
if($_SESSION['login'])
{
 ?>
<?php 
 if(isset($_POST['submit']))
 {
include_once("connection.php");
include_once("config.php");
include_once("dbConnection.php");
 date_default_timezone_set("Asia/Kolkata");
 $email= $_SESSION['login'];

 $message = $_POST['message'];
 
 $senderid =$_POST['senderid'];
 
 $date= date("Y/m/d h:i:sa");
 $query = "SELECT * FROM userregistration WHERE email='$email'";
 $run_query = mysqli_query($conn, $query) or die(mysqli_error($conn));
 if (mysqli_num_rows($run_query) > 0) {
 while ($row = mysqli_fetch_array($run_query)) {
 $name = $row['name'];
 }
 }
 $query = "SELECT * FROM affiliate WHERE email= '$email'";
 $run_query = mysqli_query($conn, $query) or die(mysqli_error($conn));
 if (mysqli_num_rows($run_query) > 0) {
 while ($row = mysqli_fetch_array($run_query)) {
 $amount = $row['amount'];
 
 if($amount>20)
 {
   $sql = "UPDATE affiliate SET amount = amount-20 WHERE email= '$email'";
   $conn->query($sql);
      $q=mysqli_query($con,"INSERT INTO senderidrequest VALUES  ('$email' , '$senderid', '$message' , 'PENDING' , '$date')")or die ("Error");
      $alert ="<p class='alert'>REQUEST FOR CUSTOM SENDER ID SUCCESSFULLY SUBMITTED</p>";
    /*  $num="6001011509";
      $message ="Hello Boss Recently Mr $name Request For Custom sender id click to approve ($senderid) https://f2sms.ml/dashboard/request-senderid/edit-details.php?u=$email";
      $authKey = "267961AbNo6OzzpuXC5c8e464d";
      $senderId ="FCLOUD";
      $route = "4";
      $postData = array(
      'authkey' => $authKey,
      'mobiles' => $num,
      'message' => $message,
      'sender' => $senderId,
      'route' => $route,
      'country'=>'91'
      );
      $url="https://control.msg91.com/api/sendhttp.php";
      $ch = curl_init();
      curl_setopt_array($ch, array(
      CURLOPT_URL => $url,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_POST => true,
      CURLOPT_POSTFIELDS => $postData
      ));
      curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
      $output = curl_exec($ch);
      if(curl_errno($ch))
      {
      echo 'error:' . curl_error($ch);
      }
      curl_close($ch);*/
      }
   
 else {
 
 echo "<script>alert('You Have Minimum 20 for sender id');</script>";
 echo "<script>window.location = '';</script>";;
 
 }
 }
 }
 else {
  echo "<script>alert('You Dont Have A FREE2SMS Affiliate Account click OK For Create Account');</script>";
  echo "<script>window.location = '';</script>";;
 
 }
 }
 ?>
 <div class="container" align="left">
 <div class='card shadow'>
 <form action="" method="post">
 <?php echo $alert ?>
 <p>SENDER ID</p>
 <input type="text" name="senderid" placeholder="TYPE SENDER ID" required>
 <p>TYPE REASON</p>
 <textarea class="message" placeholder="Why You Want Custom Sender ID" class="text" rows="5" name="message"></textarea>
 <input type="submit" class="button" name="submit" value="SUBMIT">
 </textarea>
 </form>
 </div></div>
 <style>
 
 body {font-family: Arial, Helvetica, sans-serif;}
 form {border: 3px solid #fff;}
 
 input[type=text], input[type=tel], .message {
 width: 100%;
 padding: 12px 20px;
 margin: 8px 0;
 display: inline-block;
 border: 1px solid #ccc;
 box-sizing: border-box;
 }
 .alert{
 text-align: center;
 padding:10px;
 background:#79c879;
 color:#fff;
 margin-bottom:10px;
 display:block;
 }
 .button {
 background-color: #4CAF50;
 color: white;
 padding: 14px 20px;
 margin: 8px 0;
 border: none;
 cursor: pointer;
 width: 100%;
 }
 .error {
 background-color: #4CAF50;
 color: white;
 padding: 14px 20px;
 margin: 8px 0;
 border: none;
 cursor: pointer;
 width: 300px;
 
 }
 
 .button:hover {
 opacity: 0.8;
 }
 
 .cancelbtn {
 width: auto;
 padding: 10px 18px;
 background-color: #f44336;
 }
 
 .imgcontainer {
 text-align: center;
 margin: 24px 0 12px 0;
 }
 
 img.avatar {
 width: 40%;
 border-radius: 50%;
 }
 
 .container {
 padding: 16px;
 }
 
 span.psw {
 float: right;
 padding-top: 16px;
 }
 
 /* Change styles for span and cancel button on extra small screens */
 @media screen and (max-width: 5px) {
 span.psw {
 display: block;
 float: none;
 }
 .cancelbtn {
 width: 50%;
 }
 }
 </style>
 <?php
 } else {
 header('location:logout.php');	
 }
 ?>
 <?php include_once("includes/footer.php"); ?>