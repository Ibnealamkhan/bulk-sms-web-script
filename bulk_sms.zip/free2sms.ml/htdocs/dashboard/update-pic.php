<?php 
include_once("connection.php");
if($_SERVER['REQUEST_METHOD']=='POST'){
$email = $_POST['email'];
$image = $_FILES['image']['name'];
    $ext = $_FILES['image']['type'];
    $validExt = array ("image/gif",  "image/jpeg",  "image/pjpeg", "image/png");
    if (empty($image)) {
    	$picture = $profilepic;
    }
    else if ($_FILES['image']['size'] <= 0 || $_FILES['image']['size'] > 1024000 )
    {
echo "<script>alert('Image size is not proper');
 window.location.href='profile.php';</script>";
 }
    else if (!in_array($ext, $validExt)){
        echo "<script>alert('Not a valid image');
        window.location.href='profile.php';</script>";
    }
    else {
        $folder  = 'users/';
        $imgext = strtolower(pathinfo($image, PATHINFO_EXTENSION) );
        $picture = rand(100000 , 10000000) .'.'.$imgext;
        if (move_uploaded_file($_FILES['image']['tmp_name'], $folder.$picture)) {
        $queryupdate = "UPDATE userregistration SET img = 'https://www.free2sms.ml/dashboard/users/$picture' WHERE email= '$email' " ;
        $result = mysqli_query($conn , $queryupdate) or die(mysqli_error($conn));
        if (mysqli_affected_rows($conn) > 0) {
        	echo "<script>alert('Profile Photo uploaded successfully');
        	window.location.href= 'profile.php';</script>";
        }
        else {
        	echo "<script>alert('Error! ..try again');</script>";
}
}
else {
	echo "<script>alert('Error occured while uploading! ..try again');</script>";
}
}
}
    ?>