<?php
session_start();
include_once("dbConnection.php");
include_once("config.php");
include_once("connection.php");
include_once("includes/header.php");
include_once("includes/navbar.php");
if(isset($_SESSION['login']))
{
 ?>
 <?php
 $email=$_SESSION['login'];
 
 $query = "SELECT * FROM affiliate WHERE email= '$email'";
 $run_query = mysqli_query($conn, $query) or die(mysqli_error($conn));
 if (mysqli_num_rows($run_query) > 0) {
 while ($row = mysqli_fetch_array($run_query)) {
 $id = $row['id'];
 
 }
 }
 ?>
 <div class="container" align="center">
 <h2>REDEEM HISTORY</h2>
 <div class="card shadow">
 <div class="row">
 <div class="col-lg-12">
 <div class="table-responsive">
 
 <table class="table table-bordered table-striped table-hover">
 
 <thead>
 <tr>
 
 <th>Number</th>
 <th>Amount</th>
 <th>Status</th>
 <th>Date</th>
 
 </tr>
 </thead>
 <tbody>
 <?php
 
 
 $query = "SELECT * FROM redeem WHERE id= '$id' ORDER BY date DESC";
 $run_query = mysqli_query($conn, $query) or die(mysqli_error($conn));
 if (mysqli_num_rows($run_query) > 0) {
 while ($row = mysqli_fetch_array($run_query)) {
 $number = $row['number'];
 $amount = $row['amount'];
 $status = $row['status'];
 $date = $row['date'];
 
 
 echo "<tr>";
 echo "<td>$number</td>";
 echo "<td>$amount</td>";
 echo "<td>$status</td>";
 echo "<td>$date</td>"; 
 echo "</tr>";
 echo "</tbody>";
 }
 
 }
 
 
 ?>
 
 </tbody>
 </table>
 </div>
 </div>
 </div>
 </div>
 </div>
 <?php
 } else {
 header('location:logout.php');	
 }
 
 ?>
 <?php include_once("includes/footer.php"); ?>