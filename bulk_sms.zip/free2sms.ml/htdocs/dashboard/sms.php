<?php
session_start();
include_once("dbConnection.php");
include_once("config.php");
include_once("connection.php");
include_once("includes/header.php");
include_once("includes/navbar.php");
if($_SESSION['login'])
{
 ?>
 <?php
 
 $email=$_SESSION['login'];
 
 $query = "SELECT * FROM userregistration WHERE email='$email'";
 $run_query = mysqli_query($conn, $query) or die(mysqli_error($conn));
 if (mysqli_num_rows($run_query) > 0) {
 while ($row = mysqli_fetch_array($run_query)) {

 $senderid = $row['senderid'];
 $action = $row['action'];
 
 
 }
 }
 ?>
 
 <?php
 
 $email=$_SESSION['login'];
 
 $query = "SELECT * FROM affiliate WHERE email='$email'";
 $run_query = mysqli_query($conn, $query) or die(mysqli_error($conn));
 if (mysqli_num_rows($run_query) > 0) {
 while ($row = mysqli_fetch_array($run_query)) {
 
 $amount = $row['amount'];
 
 
 }
 }
 ?>
 
  <div class="container" align="left">
     <!-- AD SPACE -->
   <!-- apgygames top -->

<br/>
     <div class="card shadow">
     
<form action="sms-send.php" method="post" >
    <center>
             <h3>Send Free Massage</h3>
         <p>SMS BALANCE:-<?php echo $amount ?></p>
         </center>
         <br>
         <lable>Mobile No</lable>
            <input  type="tel" placeholder="Number"required name="mobile">
         <lable>Sender ID (e.g, IAKHAN)</lable>
         <input  type="text" required name="sender" minlength="6" maxlength="6" <?php echo $action ?> value="<?php echo $senderid ?>">
        
         <lable>Enter Your Message</lable>
       
         
         <textarea class="message" placeholder="Enter Your Massage" class="text" rows="5" name="message"></textarea>
       
         </textarea>
     
         <center> <button class="button"  type="submit" name="submit">Send Massage <span class="glyphicon glyphicon-send"></span></button></center>
         </div>
      
         </form></div>
         </div>
        
         <style>
         
         body {font-family: Arial, Helvetica, sans-serif;}
         form {border: 3px solid #fff;}
         
         input[type=text], input[type=tel], .message {
         width: 100%;
         padding: 12px 20px;
         margin: 8px 0;
         display: inline-block;
         border: 1px solid #ccc;
         box-sizing: border-box;
         }
         
         .button {
         background-color: #4CAF50;
         color: white;
         padding: 14px 20px;
         margin: 8px 0;
         border: none;
         cursor: pointer;
         width: 100%;
         }
         .error {
         background-color: #4CAF50;
         color: white;
         padding: 14px 20px;
         margin: 8px 0;
         border: none;
         cursor: pointer;
         width: 300px;
         
         }
         
         .button:hover {
         opacity: 0.8;
         }
         
         .cancelbtn {
         width: auto;
         padding: 10px 18px;
         background-color: #f44336;
         }
         
         .imgcontainer {
         text-align: center;
         margin: 24px 0 12px 0;
         }
         
         img.avatar {
         width: 40%;
         border-radius: 50%;
         }
         
         .container {
         padding: 16px;
         }
         
         span.psw {
         float: right;
         padding-top: 16px;
         }
         
         /* Change styles for span and cancel button on extra small screens */
         @media screen and (max-width: 5px) {
         span.psw {
         display: block;
         float: none;
         }
         .cancelbtn {
         width: 50%;
         }
         }
         </style>
         <script>
         var myVar;
         
         function myFunction() {
         myVar = setTimeout(showPage, 3000);
         }
         
         function showPage() {
         document.getElementById("loader").style.display = "none";
         document.getElementById("myDiv").style.display = "block";
         }
         </script>
         <style>
         /* Center the loader */
         #loader {
         position: absolute;
         left: 50%;
         top: 50%;
         z-index: 1;
         width: 150px;
         height: 150px;
         margin: -75px 0 0 -75px;
         border: 16px solid #f3f3f3;
         border-radius: 50%;
         border-top: 16px solid #3498db;
         width: 120px;
         height: 120px;
         -webkit-animation: spin 2s linear infinite;
         animation: spin 2s linear infinite;
         }
         
         @-webkit-keyframes spin {
         0% { -webkit-transform: rotate(0deg); }
         100% { -webkit-transform: rotate(360deg); }
         }
         
         @keyframes spin {
         0% { transform: rotate(0deg); }
         100% { transform: rotate(360deg); }
         }
         
         /* Add animation to "page content" */
         .animate-bottom {
         position: relative;
         -webkit-animation-name: animatebottom;
         -webkit-animation-duration: 1s;
         animation-name: animatebottom;
         animation-duration: 1s
         }
         
         @-webkit-keyframes animatebottom {
         from { bottom:-100px; opacity:0 } 
         to { bottom:0px; opacity:1 }
         }
         
         @keyframes animatebottom { 
         from{ bottom:-100px; opacity:0 } 
         to{ bottom:0; opacity:1 }
         }
         
         #myDiv {
         display: none;
         text-align: left;
         }
         </style>
<?php
} else {
header('location:logout.php');	
}
?>
<?php include_once("includes/footer.php"); ?>