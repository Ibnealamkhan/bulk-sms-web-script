<?php
session_start();
include_once("dbConnection.php");
include_once("config.php");
include_once("connection.php");
include_once("includes/header.php");
include_once("includes/navbar.php");
if(isset($_SESSION['login']))
{
 ?>
 <?php 
 if(isset($_POST['affiliate']))
 {
 date_default_timezone_set("Asia/Kolkata");
 $email= $_SESSION['login'];
 $id= uniqid();
 
 
 // Insert record
 $query=mysqli_query($con,"insert into affiliate (id,email,click,signup,amount) values('$id','$email','0','0','10')");
 
 mysqli_query($con,$query);
  
  echo "<script>alert('Affiliate Link Successfully Generated');</script>";
  echo "<script>window.location = 'affiliate.php';</script>";;
  
 
 
 
 }
 ?>
 <?php
 $url =$_SERVER['HTTP_HOST'];
 $email=$_SESSION['login'];
 $name=$_SESSION['name'];
 
 $query = "SELECT * FROM affiliate WHERE email= '$email'";
 $run_query = mysqli_query($conn, $query) or die(mysqli_error($conn));
 if (mysqli_num_rows($run_query) > 0) {
 while ($row = mysqli_fetch_array($run_query)) {
 
 $signup = $row['signup'];
 $id = $row['id'];
 $click = $row['click'];
 $amount = $row['amount'];
 
  }

 echo "
 <div class='container' align='left'>
 <h2>AFFILIATE EARNING</h2>
 <div class='card shadow'>
  <input type='text' value='https://free2sms.ml/share.php?id=$id' id='myInput' readonly>
 
 <!-- The button used to copy the text -->
 <button class='button' onclick='myFunction()'>Copy Affiliate Link</button>
 <center>
 <label>Share With WhatsApp</label>
 <a href='https://api.whatsapp.com/send?text=Hi+Your+Friend+$name+Invited+you+to+join+FREE2SMS+and+send+sms+for+free+and+also+earn+money+through+affiliate+link+per+click+0.5+ruppes+and+per+joing+5+ruppes+minimum+redeem+20+ruppes+join+now+https://free2sms.ml/share.php?id=$id'><img src='https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcR7a9IbjVwl9l1n4Rsivnpnud3fBQajVKGacEaaOqMQgeWAmtip' height='50px' width='150px'></a>
 </center>
 <br>
 <div class='card shadow'>
 <h3>Total Click:- $click</h3>
 </div>
 <br>
 <div class='card shadow'>
 <h3>Total Sign up:- $signup</h3>
 </div>
 <br>
 <div class='card shadow'>
 <h3>Total Earning:- $amount ₹</h3>
 </div>
 
 <p>You Can Also Redeem Balance In Paytm otherwise Use As a SMS Balance</p>
 <p>Minimum Withdrew 200 </p>
 <form action='' method='post'>
 <input type='hidden' value='$id' name='id'>
 <input type='text' name='number' placeholder='Paytm Number' required>
 <input type='submit' class='button' name='redeem' value='Redeem'>
 </form>
 <br>
 <center>

 <a class='button' href='redeem-history.php'>View Redeem History</a>
 </center>
 <br>
 </div>
 </div>
 ";
}
 else {
 echo "
 <form action='' method='post'>
 
 <input class='button' type='submit' value='GENERATE AFFILIATE LINK' name='affiliate'>
 </form>
 ";
 }
 ?>
 <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
 <script type="text/javascript">
 google.charts.load("current", {packages:["corechart"]});
 google.charts.setOnLoadCallback(drawChart);
 function drawChart() {
 var data = google.visualization.arrayToDataTable([
 ['Task', 'Hours per Day'],
 ['CLICKS',     <?php echo $click ?>],
 ['SIGN UP',    <?php echo $signup ?>],
 ['EARNINGS',    <?php echo $amount ?>],
 ]);
 
 var options = {
 title: 'ANALYTICS',
 is3D: true,
 };
 
 var chart = new google.visualization.PieChart(document.getElementById('piechart_3d'));
 chart.draw(data, options);
 }
 </script>
<div class="container" align="center">
 <h2>Analytics</h2>
 <div class="card shadow">
 <div class="row">
 <div class="col-lg-12">
 <div class="table-responsive">
 
 <table class="table table-bordered table-striped table-hover">
 
 <thead>
 <tr>
 
 <div id="piechart_3d" style="width: 100%; height: 100%;"></div>
 </tr>
 </thead>
 <tbody>
 </tbody>
 </table>
 </div>
 </div>
 </div>
 </div>
 </div>
 <div class="container" align="center">
 <h2>DOWNLINE</h2>
 <div class="card shadow">
 <div class="row">
 <div class="col-lg-12">
 <div class="table-responsive">
 
 <table class="table table-bordered table-striped table-hover">
 
 <thead>
 <tr>
 
 <th>Name</th>
 
 <th>Email</th>
 <th>Date</th>
 
 </tr>
 </thead>
 <tbody>
 <?php 
 if(isset($_POST['redeem']))
 {
 date_default_timezone_set("Asia/Kolkata");
 $date= date("Y/m/d h:i:sa");
 $number=$_POST['number'];
 $id =$_POST['id'];
 $query = "SELECT * FROM affiliate WHERE id= '$id'";
 $run_query = mysqli_query($conn, $query) or die(mysqli_error($conn));
 if (mysqli_num_rows($run_query) > 0) {
 while ($row = mysqli_fetch_array($run_query)) {
 $request = $row['request'];
 $signup = $row['signup'];
 $id = $row['id'];
 $click = $row['click'];
 $amount = $row['amount'];
 $status = $row['status'];
 if($amount<200)
 {
  echo "<script>alert('You Need minimum 200 for redeem');</script>";
  echo "<script>window.location = 'affiliate.php';</script>";;
  }
 else {
 $sql = "UPDATE affiliate SET amount = amount-200 WHERE id = '$id'";
 $conn->query($sql);
 $query=mysqli_query($con,"insert into redeem (id,number,amount,status,date) values('$id','$number','200','Pending','$date')");
 
 echo "<script>alert('Your Request For Redeem Successfully received');</script>";
 echo "<script>window.location = 'affiliate.php';</script>";;
 
 }
 }
 }
 }
 ?>
 
 <?php

 
 $query = "SELECT * FROM downline WHERE id= '$id' ORDER BY date DESC";
 $run_query = mysqli_query($conn, $query) or die(mysqli_error($conn));
 if (mysqli_num_rows($run_query) > 0) {
 while ($row = mysqli_fetch_array($run_query)) {
$name = $row['name'];
 $email = $row['email'];
 
 $date = $row['date'];
 
 
 echo "<tr>";
 echo "<td>$name</td>";
 echo "<td>$email</td>";
 echo "<td>$date</td>"; 
 echo "</tr>";
 echo "</tbody>";
 }
 
 }
 
 
 ?>
 
 </tbody>
 </table>
 </div>
 </div>
 </div>
 </div>
 </div>
 <script type="text/javascript">
 function myFunction() {
 /* Get the text field */
 var copyText = document.getElementById("myInput");
 
 /* Select the text field */
 copyText.select();
 
 /* Copy the text inside the text field */
 document.execCommand("copy");
 
 /* Alert the copied text */
 alert("Copied API: " + copyText.value);
 }
 </script>
 <style>
 .button {
 background-color: #4CAF50;
 color: white;
 padding: 14px 20px;
 margin: 8px 0;
 border: none;
 cursor: pointer;
 width: 100%;
 }
 input[type=text], input[type=tel], .message {
 width: 100%;
 padding: 12px 20px;
 margin: 8px 0;
 display: inline-block;
 border: 1px solid #ccc;
 box-sizing: border-box;
 }
 .p {
 text-align:left;
 font-size:20px;
 color:red;
 }
 </style>
 <?php
 } else {
 header('location:logout.php');	
 }
 
 ?>
 <?php include_once("includes/footer.php"); ?>