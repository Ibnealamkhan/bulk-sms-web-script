<?php
session_start();
include_once("connection.php");
include_once("includes/header.php");
include_once("includes/navbar.php");
if($_SESSION['login'])
{
?>
  <style type="text/css">
  #user_para 
  {
  color:#fff;
  }
  .alert{
  text-align: center;
  padding:10px;
  background:#79c879;
  color:#fff;
  margin-bottom:10px;
  display:block;
  }
  </style>
 
<?php
if(isset($_POST['submit']))
{
$mobileNo=$_POST['mobile'];
$message = $_POST['message'];
$authKey = "267961AbNo6OzzpuXC5c8e464d";
$senderId =$_POST['sender'];
$route = "4";
$postData = array(
    'authkey' => $authKey,
    'mobiles' => $mobileNo,
    'message' => $message,
    'sender' => $senderId,
    'route' => $route,
    'country'=>'91'
);
$url="https://control.msg91.com/api/sendhttp.php";
$ch = curl_init();
    curl_setopt_array($ch, array(
    CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $postData
));
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
$output = curl_exec($ch);
$err = curl_error($curl);
 
curl_close($ch);
echo "<div class='container' align='left'>
        <!-- AD SPACE -->
      <!-- apgygames top -->

<br/>
        <div class='card shadow'>
       
<div class='alert'>Message Sent Successfully To $mobileNo</div>
<p> Your Transaction ID Is:-<b>$output $err</b> </p>
<p>To:-$mobileNo</p>
<p>From:-$senderId</p>
<p>Message:-$message</p>
</div>
</div>
";
}
?>
<?php
} else {
header('location:logout.php');	
}
?>
<?php include_once("includes/footer.php"); ?>