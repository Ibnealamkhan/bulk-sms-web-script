<?php
session_start();
if(isset($_SESSION['login'])) {

header('location: dashboard');
}
require_once 'config2.php';

$loginURL="";
$authUrl = $googleClient->createAuthUrl();
$loginURL = filter_var($authUrl, FILTER_SANITIZE_URL);

include_once("dbConnection.php");
include_once("includes/header.php");
include_once("includes/navbar.php");
if(isset($_POST['login']))
{
$email=$_POST['email'];
$password=$_POST['password'];
$ret= mysqli_query($con,"SELECT * FROM userregistration WHERE email='$email' and password='$password'");
$num=mysqli_fetch_array($ret);
$status=$num['status'];
if($num>0)
{	
if($status==2)
{
	$_SESSION['action1']="Your Account Is Banded by Admin Due To illegal activities";
	}
	else 
if($status==0)
{
	$_SESSION['action1']="YOU ARE NOT VERIFIED PLEACE VERIFY YOUR PHONE NUMBER";

}
	else {

$_SESSION['login']=$email;
$_SESSION['id']=$num['id'];
$_SESSION['name']=$num['name'];
$_SESSION ['phone']=$num['phone'];
$_SESSION ['address']=$num['address'];
$_SESSION ['img']=$num['img'];
$_SESSION ['senderid']=$num['senderid'];
$_SESSION ['action']=$num['action'];
$extra="dashboard";
$host=$_SERVER['HTTP_HOST'];
$uri=rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
header("location:http://$host$uri/$extra");
exit();
}
}
else
{
$_SESSION['action1']="Invalid username or password";
$extra="login.php";
$host  = $_SERVER['HTTP_HOST'];
$uri  = rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
header("location:http://$host$uri/$extra");
exit();
}
}
 ?>
<title>Log In To Your Account</title>
</head>
  
    
    <style>
    
    body {font-family: Arial, Helvetica, sans-serif;}
    form {border: 3px solid #fff;}
    
    input[type=text], input[type=password], input[type=email] {
    width: 300px;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
    }
    
    .button {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
    }
    
    .button:hover {
    opacity: 0.8;
    }
    
    .cancelbtn {
    width: auto;
    padding: 10px 18px;
    background-color: #f44336;
    }
    
    .imgcontainer {
    text-align: center;
    margin: 24px 0 12px 0;
    }
    
    img.avatar {
    width: 40%;
    border-radius: 50%;
    }
    
    .container {
    padding: 16px;
    }
    
    span.psw {
    float: right;
    padding-top: 16px;
    }
    label {
    text-align:left;
    }
    /* Change styles for span and cancel button on extra small screens */
    @media screen and (max-width: 200px) {
    span.psw {
    display: block;
    float: none;
    }
    .cancelbtn {
    width: 50%;
    }
    }
    </style>
    </head>
    <body>
    
    <form action="" method="post">
   <div class="container" align="center">
   <div class="card shadow">
   <a href="<?= htmlspecialchars( $loginURL ); ?>"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSSr7OXmFj0dzyXwq-H1lv_eWN9ehWpicPI6dkO3kituuhRbeLW"  alt="Login With Google" height="50px" width="100%"></a>
   
    <p><center><font color="#FF0000"><b><?php echo $_SESSION['action1']; ?><?php echo $_SESSION['action1']="";?></b></font></p></center>
    
    
    
    <div class="container">
   
    <label>Enter Your Email</label>
    <br>
    <input type="email" name="email" id="email" value=""  class="form-control" required placeholder="example@free2sms.ml">
    <br>
    <label>Enter Your Password</label>
  <br>
    <input type="password" name="password" id="password" value=""  class="form-control" required placeholder="**********">
    <br>
    <button class="button" name="login" type="submit">Login</button>
    
    
    <div class="container" style="background-color:#f1f1f1">
    <button type="button" class="cancelbtn">BACK</button>
    <span class="psw">Forgot <a href="reset-pass.php">password?</a></span>
    </div>
    </div>
    
    </form>
    </div>
    </div>
    <?php include_once("includes/footer.php"); ?>