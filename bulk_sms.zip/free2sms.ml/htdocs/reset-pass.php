<?php
include_once("config.php");
include_once("includes/header.php");
include_once("includes/navbar.php");
?>
<title>Recover Your Password</title>
  <div class="container" align="center">
     <!-- AD SPACE -->
   <!-- apgygames top -->

<br/>
     <div class="card shadow">
     <?php
     if (isset($_POST['send'])) {
     $email = $_POST['email'];
     $token = md5($email);
     $result = mysqli_query($con,"SELECT * FROM userregistration WHERE email='$email' ") or die('Error');
     while($row = mysqli_fetch_array($result)) {
     $name = $row['name'];
     $password = $row['password'];
     $email = $row['email'];
     
     
     require 'PHPMailer/PHPMailerAutoload.php';
     
     $mail = new PHPMailer;
     //$mail->SMTPDebug = 4;    
     $mail->isSMTP();                            // Set mailer to use SMTP
     $mail->Host = 'smtp.gmail.com';             // Specify main and backup SMTP servers
     $mail->SMTPAuth = true;                     // Enable SMTP authentication
     $mail->Username = 'iftikarkhan98@gmail.com';          // SMTP username
     $mail->Password = '7086303816iftikar'; // SMTP password
     $mail->SMTPSecure = 'tls';                  // Enable TLS encryption, `ssl` also accepted
     $mail->Port = 587;                          // TCP port to connect to
     
     $mail->setFrom('developer@f2sms.ml','FREE2SMS');
     $mail->addReplyTo('developer@f2sms.ml');
     $mail->addAddress($email);
     
     $mail->isHTML(true);  // Set email format to HTML
     
     
     $bodyContent = '
     
     <h3>Hello, '.$name.'</h3>
     <p>Here Is Your Account Details For <a style="color:red;" href="https://free2sms.ml" >FREE2SMS</a></p>
     <p><b>LOGIN DETAILS</b></p>
     <p>Email:- '.$email.'</p>
     <p>Password:- '.$password.'</p>
     <p>If you didn’t ask to reset your password, you can ignore this email.</p>
     <p>Thanks,</p>
     <p>FREE2SMS</p>'
     ;
     
     $mail->Subject = 'Recover Password For FREE2SMS';
     $mail->Body    = $bodyContent;
     
     
     if($mail->send() && ($count > 0)) {
     echo "<center> <font color = 'green' >Email with recover password link has been sent </font><center> " ;
     } else {
     
     echo  "<center> <font color = 'green' >Hello, $name Password Recover Link Sent To Your Email </font><center> ";
     }
     }
     }
    
     ?>
     
 <form action="" method="post">
 <input class="form-control" type="email" name="email" placeholder="ENTER YOUR EMAIL">
 <br>
 <input class="btn btn-outline-success btn-block" type="submit" name="send" value="RESET PASSWORD">
 </form>
 <br>
 </div>
 </div>
 <br><br>
 <?php include_once("includes/footer.php"); ?>
 