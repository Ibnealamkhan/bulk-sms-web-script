<?php
$conn = mysqli_connect("sql100.epizy.com","epiz_24555717","vCl8hr7bg0zGwDq","epiz_24555717_sms" ) or die ("error" . mysqli_error($conn));
?>