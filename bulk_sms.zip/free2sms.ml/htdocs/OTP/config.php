<?php
define('DB_SERVER','sql100.epizy.com');
define('DB_USER','epiz_24555717');
define('DB_PASS' ,'vCl8hr7bg0zGwDq');
define('DB_NAME', 'epiz_24555717_sms');
$con = mysqli_connect(DB_SERVER,DB_USER,DB_PASS,DB_NAME);
// Check connection
if (mysqli_connect_errno())
{
 echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
?>