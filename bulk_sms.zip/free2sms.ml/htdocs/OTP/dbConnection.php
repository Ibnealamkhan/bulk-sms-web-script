<?php
//all the variables defined here are accessible in all the files that include this one
$con= new mysqli('sql100.epizy.com','epiz_24555717','vCl8hr7bg0zGwDq','epiz_24555717_sms')or die("Could not connect to mysql".mysqli_error($con));

?>