<?php
session_start();
if(isset($_POST['submit']))
{
include_once("dbConnection.php");
include_once("config.php");
include_once("connection.php");
$username=$_SESSION['username'];
$otp1=$_POST['otp'];
$ret= mysqli_query($con,"SELECT * FROM user WHERE username='$username'");
$num=mysqli_fetch_array($ret);
$username=$num['username'];
$status=$num['status'];
$otp =$num['otp'];
if ($otp1==$otp) {
echo"<script>alert('OTP VERIFICATION SUCCESSFUL')</script>";
$result1=mysqli_query($con,"UPDATE user SET status='1' WHERE otp='$otp1'");
echo "<script>window.location = 'login.php#sucess';</script>";;
 

}
if ($otp1!==$otp) {
echo"<script>alert('OTP VERIFICATION FAILED')</script>";

}
}
 ?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

/* Full-width input fields */
input[type=text], input[type=password], input[type=tel] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

/* Add a background color when the inputs get focus */
input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Set a style for all buttons */
button {
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

button:hover {
  opacity:1;
}

/* Extra styles for the cancel button */
.cancelbtn {
  padding: 14px 20px;
  background-color: #f44336;
}

/* Float cancel and signup buttons and add an equal width */
.cancelbtn, .signupbtn {
  float: left;
  width: 50%;
}

/* Add padding to container elements */
.container {
  padding: 16px;
}

/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: #474e5d;
  padding-top: 50px;
}

/* Modal Content/Box */
.modal-content {
  background-color: #fefefe;
  margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
  border: 1px solid #888;
  width: 80%; /* Could be more or less, depending on screen size */
}

/* Style the horizontal ruler */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}
 
/* The Close Button (x) */
.close {
  position: absolute;
  right: 35px;
  top: 15px;
  font-size: 40px;
  font-weight: bold;
  color: #f1f1f1;
}

.close:hover,
.close:focus {
  color: #f44336;
  cursor: pointer;
}

/* Clear floats */
.clearfix::after {
  content: "";
  clear: both;
  display: table;
}

/* Change styles for cancel button and signup button on extra small screens */
@media screen and (max-width: 300px) {
  .cancelbtn, .signupbtn {
     width: 100%;
  }
}
</style>
</head>
<body>
<form class="modal-content" action="" method="post">
    <div class="container">
      <h1>Verify OTP</h1>
      <p>Hello,<?php echo $_SESSION['username']; ?> OTP Has Been Sent To Your Number <?php echo $_SESSION['number']; ?> </p>
      <hr>
      <label for="email"><b>ENTER OTP</b></label>
      <input type="tel" placeholder="OTP" name="otp" required>


      <div class="clearfix">
        <button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button>
        <button name="submit" type="submit" class="signupbtn">Sign Up</button>
      </div>
    </div>
  </form>
</body>
</html>