
<?php
include 'config.php';
include_once("includes/header.php");
include_once("includes/navbar.php");
if(!empty($_GET['code']) && isset($_GET['code']))
{
$code=$_GET['code'];
$sql=mysqli_query($con,"SELECT * FROM userregistration WHERE activationcode='$code'");
$num=mysqli_fetch_array($sql);
if($num>0)
{
  
$st=0;
$result =mysqli_query($con,"SELECT id FROM userregistration WHERE activationcode='$code' and status='$st'");
$result4=mysqli_fetch_array($result);   

if($result4>0) 
  {
$st=1;
$result1=mysqli_query($con,"UPDATE userregistration SET status='$st' WHERE activationcode='$code'");
$msg="Your account is activated"; 
}
else
{
$msg ="Your account is already active, no need to activate again";
}
}
else
{
$msg ="Wrong activation code.";
}
}

?>

<title>Verify Your Email</title>

 <!--/left-->
  
  <!--center-->
  <div class="container" align="center">
  <!-- AD SPACE -->
  <!-- apgygames top -->
  
  <br/>
  <div class="card shadow">
        <h3>Email Verification</h3>
		<hr >
	<p><?php echo htmlentities($msg); ?></p>
   <p> Now you can login</p>
   <p>For login <a href="login.php">Click Here</a></p>
   </div>
   </div>
   <?php include_once("includes/footer.php"); ?>