<?php 
require_once 'config2.php';
include_once("dbConnection.php");
include_once("config.php");
include_once("connection.php");
if ($id = $_SESSION['id']){
$_SESSION["id"] = $id;
}
else {
$id="DIRECT-USER";
}
if(isset($_GET['code'])){
	$googleClient->authenticate($_GET['code']);
	$_SESSION['token'] = $googleClient->getAccessToken();
	header('Location: ' . filter_var($redirectURL, FILTER_SANITIZE_URL));
}
############ Set Google access token ############
if (isset($_SESSION['token'])) {
	$googleClient->setAccessToken($_SESSION['token']);
}


if ($googleClient->getAccessToken()) {
	############ Fetch data from graph api  ############
	try {
		$gpUserProfile = $google_oauthV2->userinfo->get();
	}
	catch (\Exception $e) {
		echo 'Graph returned an error: ' . $e->getMessage();
		session_destroy();
		header("Location: ./");
		exit;
	}
	############ Store data in database  ############
	date_default_timezone_set("Asia/Kolkata");
	$date= date("Y/m/d h:i:sa");
	$password= uniqid();
	$oauthpro = "google";
	$oauthid = $gpUserProfile['id'] ?? '';
	$f_name = $gpUserProfile['given_name'] ?? '';
	$l_name = $gpUserProfile['family_name'];
	$gender = $gpUserProfile['gender'] ??  '';
	$email_id = $gpUserProfile['email'] ?? '';
	$locale = $gpUserProfile['locale'] ?? '';
	$name = "$f_name $l_name";
	$cover = '';
	$picture = $gpUserProfile['picture'] ?? '';
	$url = $gpUserProfile['link'] ?? '';
	
	$query = "SELECT * FROM userregistration WHERE oauthid = '$oauthid'" ; 
	$result= mysqli_query($conn , $query) or die (mysqli_error($conn));
	if (mysqli_num_rows($result) > 0 ) {
	$row = mysqli_fetch_array($result);
	$queryupdate ="UPDATE userregistration set name ='$name' img = '$picture' WHERE oauthid = '$oauthid'";
	
	$_SESSION['name'] = "$f_name $l_name";
	$_SESSION['login'] = $email_id;
	header("Location: dashboard#current_user");
	}
	else {
	
	$query=mysqli_query($con,"INSERT INTO  userregistration (name,email,password,activationcode,status,phone,address,senderid,img,action,api,oauthpro,oauthid) VALUES ('$name', '$email_id', '$password' , '' , '1' , '' , '' , 'FRESMS' , '$picture' , 'readonly' , '' , '$oauthpro' , '$oauthid')");  
	$query=mysqli_query($con,"insert into downline (id,email,name,date) values('$id','$email_id','$name','$date')");
	$queryupdate =  "UPDATE affiliate SET signup = signup+1 , amount = amount+5 WHERE id = '$id'";
	$result = mysqli_query($conn , $queryupdate) or die(mysqli_error($conn));
	
	$_SESSION['name'] = "$f_name $l_name";
	$_SESSION['login'] = $email_id;
	header("Location: dashboard#new_user");
	}
	/*
	$sql = "SELECT * FROM userregistration WHERE oauthid='$oauthid'";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
	  $conn->query("UPDATE userregistration set name ='$name' img = '$picture' WHERE oauthid = '$oauthid'  ");
	 } else {
		$conn->query("INSERT INTO  userregistration (name,email,password,activationcode,status,phone,address,senderid,img,action,api,oauthpro,oauthid) VALUES ('$name', '$email_id', 'Provided By Google' , '' , '1' , '' , '' , 'FRESMS' , '$picture' , 'readonly' , '' , '$oauth_pro' , '$oauthid'");  
	}
	$res = $conn->query($sql);
	$userData = $res->fetch_assoc();
	*/
     
} else {
	header("Location:/");
}


?>