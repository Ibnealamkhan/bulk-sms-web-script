<!DOCTYPE html>
<html lang="en">
   <head>
      <title>DASHBOARD- FREE2SMS</title>
      <meta name="description" content="BEST FREE BULK SMS SERVICE FOR EVERYONE" />
      <!-- Head Tags -->
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="googlebot" content="index,follow"/>
<meta name="revisit-after" content="1 days" />
<meta name="google" value="notranslate" />
<meta property="og:type" content="website" />
<link rel="stylesheet" href="https://free2sms.ml/PUBG/css/bootstrap.min.css">
<link rel="stylesheet" href="https://free2sms.ml/PUBG/css/main.css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
<script src="https://free2sms.ml/PUBG/js/slim.min.js"></script>
<script src="https://free2sms.ml/PUBG/js/popper.min.js"></script>
<script src="https://free2sms.ml/PUBG/js/bootstrap.min.js"></script>
<meta name="msapplication-TileColor" content="#343a40">
<meta name="msapplication-TileImage" content="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQBUh4P21uWgm2QKP4W2uVzv5l1897wlrZoFajBHNE4Be1Fr0Mi">
<meta name="theme-color" content="#343a40">
<script type="text/javascript" src="https://s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5c9d939c74650323"></script>
  
  <!-- Global site tag (gtag.js) - Google Analytics -->
  <script async src="https://www.googletagmanager.com/gtag/js?id=UA-136338072-1"></script>
  <script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  
  gtag('config', 'UA-136338072-1');
  </script>
  
  
  </head>