<html>
<?php 
$api=$_GET['api'];
$password=$_GET['pass'];
 ?>

 <head>
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <!-- Global site tag (gtag.js) - Google Analytics -->
 <script async src="https://www.googletagmanager.com/gtag/js?id=UA-136338072-1"></script>
 <script>
 window.dataLayer = window.dataLayer || [];
 function gtag(){dataLayer.push(arguments);}
 gtag('js', new Date());
 
 gtag('config', 'UA-136338072-1');
 </script>
 
 
<title>FREE2SMS API </title>
  
    <style>
    
    body {font-family: Arial, Helvetica, sans-serif;}
    form {border: 3px solid #fff;}
    
    input[type=text], input[type=tel], .message {
    display: block;
    border: 1px solid #ccc;
    border-radius: 5px;
    background: #fff;
    padding: 15px;
    outline: none;
    width: auto;
    margin-bottom: 20px;
    transition: 0.3s;
    -webkit-transition: 0.3s;
    -moz-transition: 0.3s;
    }
    
    .button {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
    }
    .error {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 300px;
   
    }
    
    .button:hover {
    opacity: 0.8;
    }
    
    .cancelbtn {
    width: auto;
    padding: 10px 18px;
    background-color: #f44336;
    }
    
    .imgcontainer {
    text-align: center;
    margin: 24px 0 12px 0;
    }
    
    img.avatar {
    width: 40%;
    border-radius: 50%;
    }
    
    .container {
    padding: 16px;
    }
    
    span.psw {
    float: right;
    padding-top: 16px;
    }
    
    /* Change styles for span and cancel button on extra small screens */
    @media screen and (max-width: 5px) {
    span.psw {
    display: block;
    float: none;
    }
    .cancelbtn {
    width: 50%;
    }
    }
    </style>
    </head>
    
    <body>
    <iframe src="sendhttp-api.php?api=<?php echo $api ?>&pass=<?php echo $password ?>" height="100%" width="100%" frameBorder="0">
    </body>
    
    </html>
    
    