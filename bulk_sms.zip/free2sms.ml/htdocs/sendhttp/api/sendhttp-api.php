<html>

<?php
include_once("dbConnection.php");
include_once("config.php");
include_once("connection.php");

$api=$_GET['api'];
$password=$_GET['pass'];
$query = "SELECT * FROM userregistration WHERE api ='$api' and password ='$password'"  ; 
$result= mysqli_query($conn , $query) or die (mysqli_error($conn));
if (mysqli_num_rows($result) > 0 ) {
$row = mysqli_fetch_array($result);
$email = $row['email'];
$name = $row['name'];
$senderid = $row['senderid'];
$action = $row['action'];
$status=$row['status'];
}
if ($status==2){
echo "<br><br><br><br><br><br><br><br>
	<p class='alert'>Your Account Has Blocked By Admin Due To illegal activities</p>";

}
else {
$query = "SELECT * FROM affiliate WHERE email ='$email'"  ; 
$result= mysqli_query($conn , $query) or die (mysqli_error($conn));
if (mysqli_num_rows($result) > 0 ) {
$row = mysqli_fetch_array($result);
$amount = $row['amount'];



echo '


<form action="sms-send.php" method="post" >
    
    <center>
    
             <h3>FREE2SMS API</h3>
        
         </center>
         <label>Hello, '.$name.'</label>
         <p>SMS BALANCE:- '.$amount.'</p>
         
         <lable>Mobile No</lable>
         
            <input type="tel" placeholder="MOBILE NUMBER"required name="mobile">
         <input name="email" type="hidden" value="'.$email.'">
        
         <lable>Sender ID (e.g, IAKHAN)</lable>
         
         <input type="text" value="'.$senderid.'"required name="sender" minlength="6" maxlength="6"  '.$action.'>
         
           <p>Type Message</p>
         
         <textarea class="message" placeholder="Enter Your Massage" class="text" rows="5" name="message"></textarea>
         
         
         
         <center> <button class="button" type="submit" name="submit" >Send Massage</button></center>
         
         
         </form>
         
';
}
 else {

	echo
	"
	<br><br><br><br><br><br><br><br>
	<p class='error'>API or Password Doesn't exist our database</p>";
	}
	
}

 ?>
 <head>
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 
<title>FREE2SMS- SEND SMS THROUGH API</title>
  
    <style>

    body {font-family: Arial, Helvetica, sans-serif;
    
    }
    form {border: 3px solid #fff;}
   
    
    
    input[type=text], input[type=tel], .message {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    
    border: 1px solid #ccc;
    box-sizing: border-box;
   
    
    
    }
    
    
    .button {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
    }
    .error {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 300px;
   
    }
    .alert {
    background-color:red;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 300px;
    
    }
    .button:hover {
    opacity: 0.8;
    }
    
    .cancelbtn {
    width: auto;
    padding: 10px 18px;
    background-color: #f44336;
    }
    
    .imgcontainer {
    text-align: center;
    margin: 24px 0 12px 0;
    }
    
    img.avatar {
    width: 40%;
    border-radius: 50%;
    }
    
    .container {
    padding: 16px;
    }
    
    span.psw {
    float: right;
    padding-top: 16px;
    }
    
    /* Change styles for span and cancel button on extra small screens */
    @media screen and (max-width: 5px) {
    span.psw {
    display: block;
    float: none;
    }
    .cancelbtn {
    width: 50%;
    }
    }
    </style>
    </head>
    <body>
    </body>
    </html>
    
    