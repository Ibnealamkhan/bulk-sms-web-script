<?php 
session_start();
if ($id = $_SESSION['id']){
$_SESSION["id"] = $id;
}
else {
$id="DIRECT-USER";
}
?>
<?php

if(isset($_SESSION['login'])) {

header('location: dashboard');
}
require_once 'config2.php';

$loginURL="";
$authUrl = $googleClient->createAuthUrl();
$loginURL = filter_var($authUrl, FILTER_SANITIZE_URL);

include_once("config.php");
include_once("connection.php");
include_once("dbConnection.php");
include_once("includes/header.php");
include_once("includes/navbar.php");
if(isset($_POST['submit'])){
date_default_timezone_set("Asia/Kolkata");
$date= date("Y/m/d h:i:sa");
$name=$_POST['name'];
$email=$_POST['email'];
$password=$_POST['password'];
$phone=$_POST['phone'];
$address=$_POST['address'];
$img = "profile.jpeg";
$senderid = "FRESMS";
$status=0;
$action = "readonly";
$activationcode=md5($email.time());

$query = "SELECT * FROM userregistration WHERE email = '$email'" ; 
   $result= mysqli_query($conn , $query) or die (mysqli_error($conn));
   if (mysqli_num_rows($result) > 0 ) {
   $row = mysqli_fetch_array($result);
  
 echo "<script>alert('This email $email already used by another account');</script>";
 echo "<script>window.location = 'reset-pass.php';</script>";;
 
 }
 else {
 
 
if ($row == 0 ) {
$query=mysqli_query($con,"insert into userregistration (name,email,password,activationcode,status,phone,address,senderid,img,action) values('$name','$email','$password','$activationcode','0','$phone','$address','$senderid','$img','$action')");
$query=mysqli_query($con,"insert into downline (id,email,name,date) values('$id','$email','$name','$date')");

/*require 'PHPMailer/PHPMailerAutoload.php';

$mail = new PHPMailer;
//$mail->SMTPDebug = 4;    
$mail->isSMTP();                            // Set mailer to use SMTP
$mail->Host = 'smtp.gmail.com';             // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                     // Enable SMTP authentication
$mail->Username = 'iftikarkhan98@gmail.com';          // SMTP username
$mail->Password = '7086303816iftikar'; // SMTP password
$mail->SMTPSecure = 'tsl';                  // Enable TLS encryption, `ssl` also accepted
$mail->Port = 587;                          // TCP port to connect to

$mail->setFrom('iftikarkhan98@gmail.com','FREE2SMS');
$mail->addReplyTo('helpsexam@gmail.com');
$mail->addAddress($email);

$mail->isHTML(true);  // Set email format to HTML

$bodyContent = '

<h3>Hello, '.$name.'</h3>
<p>Verify Your Email For <a style="color:red;" href="https://free2sms.ml" >FREE2SMS</a> Click Bellow link And Verify Your Email</p>
<center>
<a style="background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;" <a href="https://studyhelps.co.in/sms/email_verification.php?code='.$activationcode.'">Verify Your Email</a>
</center>
</center>
<br>
<p><b>LOGIN DETAILS</b></p>
<p>Email:-'.$email.'</p>
<p>Password:-'.$password.'</p>
<p>Thanks,</p>
<p>FREE2SMS</p>'
;

$mail->Subject = 'Verify Your Email';
$mail->Body    = $bodyContent;


if($mail->send() && ($count > 0)) {
	echo "<center> <font color = 'green' >Email with recover password link has been sent </font><center> " ;

*/
}
else {

    echo  "<center> <font color = 'red' >'Success'</font><center> ";
    }
    
$queryupdate =  "UPDATE affiliate SET signup = signup+1 , amount = amount+5 WHERE id = '$id'";
 $result = mysqli_query($conn , $queryupdate) or die(mysqli_error($conn));
 
 $num=$phone;
 $message ="Hello $name here is your activation link http://number-verify.22web.org/?code=$activationcode From,FREE2SMS";
 $authKey = "267961AbNo6OzzpuXC5c8e464d";
 $senderId ="FRESMS";
 $route = "4";
 $postData = array(
 'authkey' => $authKey,
 'mobiles' => $num,
 'message' => $message,
 'sender' => $senderId,
 'route' => $route,
 'country'=>'91'
 );
 $url="https://control.msg91.com/api/sendhttp.php";
 $ch = curl_init();
 curl_setopt_array($ch, array(
 CURLOPT_URL => $url,
 CURLOPT_RETURNTRANSFER => true,
 CURLOPT_POST => true,
 CURLOPT_POSTFIELDS => $postData
 ));
 curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
 curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
 $output = curl_exec($ch);
 if(curl_errno($ch))
 {
 echo 'error:' . curl_error($ch);
 }
 curl_close($ch);
 /*
 $num1="6001011509";
 $message1 ="Hello Alam Khan Boss Recently Mr $name Joined Your Website Here is His/Her Login Details Email:- $email Password:- $password And Number:- $phone";
 $authKey1 = "267961AbNo6OzzpuXC5c8e464d";
 $senderId1 ="FCLOUD";
 $route1 = "4";
 $postData1 = array(
 'authkey' => $authKey1,
 'mobiles' => $num1,
 'message' => $message1,
 'sender' => $senderId1,
 'route' => $route1,
 'country'=>'91'
 );
 $url="https://control.msg91.com/api/sendhttp.php";
 $ch = curl_init();
 curl_setopt_array($ch, array(
 CURLOPT_URL => $url,
 CURLOPT_RETURNTRANSFER => true,
 CURLOPT_POST => true,
 CURLOPT_POSTFIELDS => $postData1
 ));
 curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
 curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
 $output = curl_exec($ch);
 if(curl_errno($ch))
 {
 echo 'error:' . curl_error($ch);
 }
 curl_close($ch);
*/
$_SESSION['action1']="ACTIVATION LINK SENT TO YOUR MOBILE PLEASE VERIFY YOUR NUMBER";
echo "<script>window.location = 'login.php';</script>";;

}
}
 ?>
<title>Create Free Bulk SMS Account For Free</title>
</head>
<style>
body {font-family: Arial, Helvetica, sans-serif;}
form {border: 3px solid #fff;}

input[type=text], input[type=password], input[type=tel], input[type=email] {
  width: 320px;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

.button {
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 300px;
}

.button:hover {
  opacity: 0.8;
}

.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}

.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
}

img.avatar {
  width: 40%;
  border-radius: 50%;
}

.container {
  padding: 16px;
}

span.psw {
  float: right;
  padding-top: 16px;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}
.alert{
  text-align: center;
  padding:10px;
  background:#79c879;
  color:#fff;
  margin-bottom:10px;
  display:block;
  }
</style>
  

<body> 

    <!--Step 1:Adding HTML-->
<div class="container" align="left">
 <div class="card shadow">
 <br>
 <a href="<?= htmlspecialchars( $loginURL ); ?>"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSSr7OXmFj0dzyXwq-H1lv_eWN9ehWpicPI6dkO3kituuhRbeLW"  alt="Login With Google" height="50px" width="100%"></a>
 <br>
     <form name="insert" action="" method="post"> 

          
                 <label>Name</label>
                 <br>
                <input type="text" name="name" id="name" value="" placeholder="ENTER NAME"  required>
                <br>
                <label>Email</label>
                <br>
                <input type="email" name="email" id="email" value="" placeholder="ENTER EMAIL"  required>
                 <br>
                <label>Password</label>
                <br>
                <input type="password" name="password" id="password" placeholder=" ENTER PASSWORD" value=""  required>
                 <br>
                <label>Number</label>
                <br>
                <input type="tel" name="phone" id="phone" value="" placeholder="ENTER NUMBER"  required>
                 <br>
                <label>Address</label>
                <br>
                <input type="text" name="address" id="address" placeholder="ENTER ADDRESS" value=""   required>
                <br>
                <input type="checkbox"  required>I Agree Terms & Privacy
                
                <p>By creating an account you agree to our <a href="#">Terms & Privacy</a>.</p> 
                <center>
                <button class="button" name="submit" type="submit" class="signupbtn">Sign Up</button> 
                </center>
                 </form>
           

    </div> 
    </div>
    <?php include_once("includes/footer.php"); ?>