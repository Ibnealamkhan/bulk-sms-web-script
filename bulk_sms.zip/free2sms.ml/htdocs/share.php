<?php 
include_once("config.php");
include_once("connection.php");
include_once("dbConnection.php");
session_start();
if ($id =$_GET['id']) {
$_SESSION["id"] = $id;
$query = "SELECT * FROM affiliate WHERE id = '$id'" ; 
 $result= mysqli_query($conn , $query) or die (mysqli_error($conn));
 if (mysqli_num_rows($result) > 0 ) {
 $row = mysqli_fetch_array($result);
 $email = $row['email'];
 }
 }
/*$id !== $_GET['id'];
else {
header('location: https://free2sms.ml?redirect');
}*/
?>
<?php 
$query = "SELECT * FROM userregistration WHERE email = '$email'" ; 
 $result= mysqli_query($conn , $query) or die (mysqli_error($conn));
 if (mysqli_num_rows($result) > 0 ) {
 $row = mysqli_fetch_array($result);
 $name = $row['name'];
 $img = $row['img'];
 }

?>
<?php
include_once("config.php");
include_once("connection.php");
include_once("dbConnection.php");
 $sql = "UPDATE affiliate SET click = click+1 , amount = amount+.5 WHERE id = '$id'";
 $conn->query($sql);
?>
<!DOCTYPE html>
<html>
<title>EARN FREE PAYTM CASH THROUGH FREE2SMS | PER SIGN UP 20 RUPEES | JOIN NOW</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="refresh" content="10;url=https://free2sms.ml/">

<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<body>

<div class="w3-container">
  <br>

  <div class="w3-card-4 w3-dark-grey" style="width:100%">

    <div class="w3-container w3-center">
      <h3>You Are Invited By</h3>
      <img src="<?php echo $img ?>" alt="Avatar" style="width:80%">
      <h5><?php echo $name ?></h5>
<p>Please Wait... 10 second We Will Be Redirect You To Home Page</p>
      <div class="w3-section">
        <a href="https://free2sms.ml?iagree" class="w3-button w3-green">I WANT TO JOIN</a>
        </div>
    </div>

  </div>
</div>

</body>
</html>